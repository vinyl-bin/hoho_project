package hoho_project.hoho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HohoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HohoApplication.class, args);
	}

}
